package com.example.trial;

import java.util.LinkedList;
import java.util.List;

public class MainClass {
	private static LinkedList<Integer> list;
	private static LinkedList<Integer> reverseList;
	private static int counter =0;
	
	private String value;
	
	public static void main(String[] args) {
		list = new LinkedList<Integer>();
		
		for(int i=0;i<24;i++) {
			list.add(i);
		}
		
		reverseList = reverse(list);
		System.out.println("reverseList " + reverseList);
		
		System.out.println("counter ++ " + counter++);
		System.out.println("++ counter " + ++counter);
		
		/*if(new String("").trim().length() > 0) {
			System.out.println("space returned");
		}else {
			System.out.println(" trimmed ");
		}*/
	}
	
	private static LinkedList<Integer> reverse(LinkedList<Integer> list) {
		System.out.println("list : " + list + " " + list.size()) ;
		LinkedList<Integer> reverseList = new LinkedList<Integer>();
		
		for(int i=0;i<list.size()/2;i++) {
			int val = list.removeLast();
			System.out.println("i:" + i + " val " + val);
			reverseList.add(val);
		}
		
		for(int i=list.size()/2;i<list.size();i++) {
			int val = list.removeLast();
			System.out.println("i:" + i + " val " + val);
			reverseList.add(val);
		}
		
		for(int i=list.size()/4;i<list.size();i++) {
			int val = list.removeLast();
			System.out.println("i:" + i + " val " + val);
			reverseList.add(val);
		}
		
		for(int i=list.size()/6;i<list.size();i++) {
			int val = list.removeLast();
			System.out.println("i:" + i + " val " + val);
			reverseList.add(val);
		}
		
		for(int i=list.size()/8;i<list.size();i++) {
			int val = list.removeLast();
			System.out.println("i:" + i + " val " + val);
			reverseList.add(val);
		}
		
		for(int i=list.size()/10;i<list.size();i++) {
			int val = list.removeLast();
			System.out.println("i:" + i + " val " + val);
			reverseList.add(val);
		}
		
		for(int i=list.size()/12;i<list.size();i++) {
			int val = list.removeLast();
			System.out.println("i:" + i + " val " + val);
			reverseList.add(val);
		}
		
		return reverseList;
	}

}
