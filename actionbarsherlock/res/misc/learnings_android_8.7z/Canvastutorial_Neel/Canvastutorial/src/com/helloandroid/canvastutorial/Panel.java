package com.helloandroid.canvastutorial;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

import android.R.bool;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;



public class Panel extends SurfaceView implements SurfaceHolder.Callback, OnGestureListener{
	private CanvasThread canvasthread;
	public Context mContext;
	public GestureDetector mGestureDetector;
	public int last_x,last_y;
	public ArrayList<Point> BtnPoints = new ArrayList<Point>();
	public ArrayList<Rect> BtnRect = new ArrayList<Rect>();
	public int item_clicked=0;
	public float current_x,current_y;
	public int on_moved=1;
	public boolean move_started =false;
	int down_Y;
	ArrayList<Point> points_X = new ArrayList<Point>();

	Bitmap a = decodeSampledBitmapFromResource(getResources(), R.drawable.scanning_active, 50, 50);
	Bitmap b = decodeSampledBitmapFromResource(getResources(), R.drawable.manual_active, 50, 50);
	Bitmap c = decodeSampledBitmapFromResource(getResources(), R.drawable.change_admin_active, 50, 50);
	Bitmap d = decodeSampledBitmapFromResource(getResources(), R.drawable.settings_active, 50, 50);
	
	
	
	/*public Panel(Context context, AttributeSet attr) {
    	super(context, attr);
    	this.mContext = context;
	}*/
	
	
    public Panel(Context context, AttributeSet attrs) {
		super(context, attrs); 
		// TODO Auto-generated constructor stub
	    getHolder().addCallback(this);
	    canvasthread = new CanvasThread(getHolder(), this);
	    mGestureDetector = new GestureDetector(context, this);
	    setFocusable(true);
	    mContext = context;
	    
	}

	 


	 public Panel(Context context) {
		   super(context);
		    getHolder().addCallback(this);
		    canvasthread = new CanvasThread(getHolder(), this);
		    setFocusable(true);
		
	    }


	@SuppressLint("DrawAllocation")
	@Override
	public void onDraw(Canvas canvas) {
		
		final int height = canvas.getHeight();
		final int width = canvas.getWidth();	
		
		canvas.drawColor(Color.BLACK);
		Paint p2 = new Paint();
		p2.setAntiAlias(true);				
		p2.setColor(Color.GREEN);
		p2.setStyle(Paint.Style.STROKE);
		p2.setStrokeWidth(2);
		
		
		Paint p1 = new Paint();
		p1.setAntiAlias(true);				
		p1.setColor(Color.RED);
		p1.setStyle(Paint.Style.STROKE);
		p1.setStrokeWidth(2);
		
		Paint p = new Paint();
		p.setAntiAlias(true);				
		p.setColor(Color.WHITE);
		p.setStyle(Paint.Style.STROKE);
		p.setStrokeWidth(2);
		
		float radius = (height/2) - 50;
		canvas.drawCircle(0, height/2, radius, p);		
		
		int st=1;
		for(int a = -360; a < 360; a += st) {

			int x = (int) (radius * Math.cos(a)); 
			int y = (int) ((height/2) + radius * Math.sin(a));
			Point pt = new Point();
			pt.x = x;
			pt.y= y;
			points_X.add(pt);
		
			float d1 =(float)(radius * Math.cos(a)); 
			float d2 = (float) ((height/2) + radius * Math.sin(a));
			
			//canvas.drawPoint(d1, d2, p1);
		}
		
		BtnPoints.clear();
		BtnRect.clear();
		
		for(int i = 0 ; i<4 ; i++){
	        
			float mAngle = 	(float) ((Math.PI / 3 )- i * Math.PI / 4.5);
			double x = 0 + Math.cos(mAngle) * radius;
			double y = (height/2) - Math.sin(mAngle) * radius;
			
			int rl,rt,rr,rb;
			canvas.drawLine(0,(float)(height/2),(float) x,(float) y, p2);
			
			if(i==0)
			{
			rl = (int) (x) ;
			rt = (int) (y);
			rr = (int) (x + a.getWidth()) ;
			rb = (int) (y +a.getHeight()) ;
				
			Rect btn1 = new Rect(rl, rt, rr, rb);
			
			BtnRect.add(btn1);
			if(on_moved == 1){
			//canvas.drawRect(btn1, p1);
			
//			canvas.drawBitmap(a, (float)x, (float)y, null);
			}
			}
			else if(i==1)
			{
				rl = (int) (x) ;
				rt = (int) (y);
				rr = (int) (x + b.getWidth()) ;
				rb = (int) (y +b.getHeight()) ;
					
				Rect btn1 = new Rect(rl, rt, rr, rb);
				
				BtnRect.add(btn1);
				if(on_moved == 1){
				//	canvas.drawRect(btn1, p1);
					
//				canvas.drawBitmap(b, (float)x, (float)y, null);
				}
			}
				
				else if(i==2)
				{
					rl = (int) (x) ;
					rt = (int) (y);
					rr = (int) (x + c.getWidth()) ;
					rb = (int) (y +c.getHeight()) ;
						
					Rect btn1 = new Rect(rl, rt, rr, rb);
					
					BtnRect.add(btn1);
					if(on_moved == 1){
					//	canvas.drawRect(btn1, p1);
//					canvas.drawBitmap(c, (float)x, (float)y, null);
					}
				}
				else if(i==3)
				{
					rl = (int) (x) ;
					rt = (int) (y);
					rr = (int) (x + d.getWidth()) ;
					rb = (int) (y +d.getHeight()) ;
						
					Rect btn1 = new Rect(rl, rt, rr, rb);
					
					BtnRect.add(btn1);
					if(on_moved == 1){
				//canvas.drawRect(btn1, p1);
//				canvas.drawBitmap(d, (float)x, (float)y, null);
					}
				}
				
			
			canvas.drawPoint((float)x, (float)y, p1);	
			
			BtnPoints.add(new Point((int) x,(int) y));				

		}
		
		
		/*if (move_started ==  true)
		{
			Log.i("Move Started", "In");
			
			if (item_clicked == 1)
			{
				
				Log.i("Move Started", "Item 1 clicked");
			   Point item1_pt;
			   Point item2_pt;
			   		   
			   
			 item1_pt =  BtnPoints.get(1);
			 item2_pt = BtnPoints.get(2);
			 
			 int current_x = item1_pt.x ;
			 int current_y = item1_pt.y;
			 int current_ptIndex; 
			 
			 current_ptIndex = points_X.indexOf(item1_pt);
			 Log.i("Move Started", "currrent index  " + current_ptIndex );
			 
			 current_ptIndex ++;
			 
			 Log.i("Move Started", "currrent _x " + current_x );
			 Log.i("Move Started", "currrent _Y " + current_y );
			 Log.i("Move Started", "item 2  _x " + item2_pt.x );
			 Log.i("Move Started", "item 2 _y " + item2_pt.y );
			 
			 while (current_x <= item2_pt.x && current_y <= item2_pt.y)
			 {
				 Log.i("Move Started", "in While"); 
				 current_x =	points_X.get(current_ptIndex).x;
				 current_y =	points_X.get(current_ptIndex).y;
				canvas.drawBitmap(a, (float)current_x, (float)current_y, null);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				current_ptIndex ++;
				
			 }
			 
			 
			}
		}*/
		
				
		/*if(item_clicked == 1 || item_clicked == 2){			
			//point of scanning
			//float diff_y = (current_y - BtnPoints.get(0).y);
			
			if(current_x !=0 && current_y !=0){
				//int X = (int) Math.sqrt((Math.pow(radius, 2)) - (Math.pow(current_y, 2)));
				
				
				//double theta_radians = Math.atan2(delta_y, delta_x);
					
				for(int i = 0 ; i<4 ; i++){
			        float delta_x =   current_x - BtnPoints.get(i).x;
					float delta_y =  current_y - BtnPoints.get(i).y;
					
					double new_rad =Math.atan2( delta_y, delta_x) * 180 / Math.PI;
					double x = 0 + Math.cos(new_rad) * radius;
					double y = (height/2) - Math.sin(new_rad) * radius;
					
					canvas.drawPoint((float) x,(float) y, p2);
					
					//double x = 0 + Math.cos(-theta_radians) * radius;
					//double y = (height/2) - Math.sin(-theta_radians) * radius;
//					canvas.drawLine(0,(float)(height/2),(float) x,(float) y, p);
					
					float de_x1 = (float) (current_x -BtnPoints.get(i).x);
					float de_y1 = (float) (current_y -BtnPoints.get(i).y);
					double the_rad_two = Math.atan2(de_y1, de_x1);
					
					
					double btn1Displacement_X = (BtnPoints.get(i).x) + x;
					double btn1Displacement_Y = (BtnPoints.get(i).y) + y;
					
					float de_x = (float) (btn1Displacement_X - 0);
					float de_y = (float) (btn1Displacement_Y - (height/2));
					double the_rad = Math.atan2(de_y, de_x);
					
					double de1_x = 0 + Math.cos(-the_rad_two) * radius;
					double de2_y = (height/2) - Math.sin(-the_rad_two) * radius;
					
			//	canvas.drawLine(0,(float)(height/2),(float) de1_x,(float) de2_y, p);
						
					switch (i) {
					case 0:		
						canvas.drawBitmap(a,(float) de1_x,(float) de2_y, null);
						break;
					case 1:
						canvas.drawBitmap(b,(float) de1_x,(float) de2_y, null);
						break;
					case 2:
						canvas.drawBitmap(c,(float) de1_x,(float) de2_y, null);
						break;
					case 3:
						canvas.drawBitmap(d,(float) de1_x,(float) de2_y, null);
						break;
					default:
						break;
					}
					
				}
			}
		}*/
				
			/*	double x = 0 + Math.cos(-theta_radians) * radius;
				double y = (height/2) - Math.sin(-theta_radians) * radius;
				
				canvas.drawLine(0,(float)(height/2),(float) x,(float) y, p);*/
				
				//canvas.drawLine(0,(float)(height/2),(float) x,(float) y, p);
				
		/*		
				if (item_clicked == 2){
					canvas.drawBitmap(b,(float) x,(float) y, null);
				}
				 
				else if (item_clicked == 3){
					canvas.drawBitmap(c,(float) x,(float) y, null);
				}
				
				else if (item_clicked == 4){
					canvas.drawBitmap(d,(float) x,(float) y, null);
				}
				
				else if (item_clicked == 1)
				{
					canvas.drawBitmap(a,(float) x,(float) y, null);
					
					
					Point btn2 ;
				
					btn2 = BtnPoints.get(1);
					
					float delta_x1; 
					float delta_y1 ;
					
					double x1 = 0 + Math.cos(-theta_radians) * radius;
					double y1 = (height/2) - Math.sin(-theta_radians) * radius;
					canvas.drawLine(0, height/2,(float) x1, (float) y1,p);
					
					//double theta_radians1 = Math.atan2(delta_y1,delta_x1);
						
					//double x1 = 0 + Math.cos(-theta_radians1) * radius;
					//double y1 = (height/2) - Math.sin(-theta_radians1) * radius;
								
					
				
					canvas.drawBitmap(b,(float) x1,(float) y1, null);
									
				}*/
				
				
				
			//}
			//
			//BtnPoints.get();
		//}
		
		
		
		        
      /*  int btn1_x ,btn1_y;
        
       int a1 = height/4;
        int b1 = width/4;
		Point btn1_pt = new Point();
		btn1_pt.x = points_X.get(0).x + a1;
				btn1_pt.y = points_X.get(0).y +b1;
				
				
				 Set<Point> foo = new HashSet<Point>(points_X);
						 
        btn1_x = Collections.binarySearch(foo, btn1_pt,new Comparator<Point>() {

        	  public int compare(final Point p1, final Point p2) {
        	    return (int) p1.distanceSq(p2);
        	  }
        	});
        
        
        Point min_Pt = new Point();
        Point max_Pt = new Point();
        
        min_Pt = Collections.min(foo,new Comparator<Point>());
        max_Pt = Collections.max(points_X);*/
        
        
        
		
		
		/*int st=1;
		for(int a = -90; a < 90; a += st) {
			
			
			
	        int y = (int) ((height/2) + ((height/2 - 10) - 2) * Math.sin(a * Math.PI / 180));
				     
	        
	        //canvas.drawPoint(x, y, p);
	        
	        
	        
	        Log.i("XY", x +"," +y);
	        if((a % 2) == 0 && a!= -90){
//	        	int startAngle = (int) (180 / Math.PI * Math.atan2(x - last_x, y - last_y));
	        //	float radius = (height/2 - 10);
	        	final RectF oval = new RectF();
	        	oval.set(x - radius, y - radius, last_x + radius,last_y+ radius);
	        	Path myPath = new Path();
	        	float startAngle = (float) Math.toDegrees( Math.atan2(y-last_y, x-last_x));
	        	float sweepAngle = (float) Math.toDegrees( Math.atan2(y-last_y, x-last_x)) - startAngle;
	        	Log.i("SweepAngle",""+sweepAngle);
	        	Log.i("startAngle",""+startAngle);
	        	myPath.arcTo(oval, startAngle, -(float) sweepAngle, true);
	        	
	        	//canvas.drawLine(x, y, last_x, last_y, p);
	        	Log.i("Drawline","Drawline");	        
	        }
	        last_x = x;	        	
        	last_y = y;
	        else{
	        	
	        	Log.i("Last XY", last_x +"," +last_y);
	        }	        	        
	        
//	        if(a == 90) 
//	        		LandingActivity.path.moveTo(x, y);
//        	else	                		
	    }*/
		//p.setStrokeWidth(2);
		//canvas.drawCircle(0,(height/2), (height/2 - 20), p);
		
	}
	 
	
	public static int calculateInSampleSize(BitmapFactory.Options options,
			int reqWidth, int reqHeight) {
		// Raw height and width of image
		final int height = options.outHeight;
		final int width = options.outWidth;
		int inSampleSize = 1;

		if (height > reqHeight || width > reqWidth) {

			// Calculate ratios of height and width to requested height and
			// width
			final int heightRatio = Math.round((float) height
					/ (float) reqHeight);
			final int widthRatio = Math.round((float) width / (float) reqWidth);

			// Choose the smallest ratio as inSampleSize value, this will
			// guarantee
			// a final image with both dimensions larger than or equal to the
			// requested height and width.
			inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
		}

		return inSampleSize;
	}

	public static Bitmap decodeSampledBitmapFromResource(Resources res,
			int resId, int reqWidth, int reqHeight) {

		// First decode with inJustDecodeBounds=true to check dimensions
		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inJustDecodeBounds = true;
		BitmapFactory.decodeResource(res, resId, options);

		// Calculate inSampleSize
		options.inSampleSize = calculateInSampleSize(options, reqWidth,
				reqHeight);

		// Decode bitmap with inSampleSize set
		options.inJustDecodeBounds = false;
		return BitmapFactory.decodeResource(res, resId, options);
	}
	
	public static PointF PointOnCircle(float radius, float angleInDegrees, PointF origin)
    {
        // Convert from degrees to radians via multiplication by PI/180        
        float x = (float)(radius * Math.cos(angleInDegrees * Math.PI / 180F)) + origin.x;
        float y = (float)(radius * Math.sin(angleInDegrees * Math.PI / 180F)) + origin.y;

        return new PointF(x, y);
    }
	
//	@SuppressLint("ShowToast")
//	@Override
//	public boolean onTouchEvent(MotionEvent event) {
//		mGestureDetector.onTouchEvent(event);
//		if(event.getAction() == MotionEvent.ACTION_MOVE){
//			on_moved = 0;
//			move_started = true;
//			if(item_clicked == 1 || item_clicked ==2){
//			current_x  = event.getX();	
//			current_y  = event.getY();
//			}
//		}
//		
//		
//		if(event.getAction() == MotionEvent.ACTION_DOWN){
//			on_moved = 0;
//			down_Y = 0;
//			Point oCurrentPt = new Point((int) event.getX(),(int) event.getY());
//			
//			Log.i("Current Pt: ", "" + oCurrentPt.x + " " + oCurrentPt.y);
//			
//			for (int i=0;i<BtnRect.size();i++)
//			{
//			Rect tempRect;
//			tempRect = BtnRect.get(i);
//			
//			if (tempRect.left < event.getX() && tempRect.right > event.getX() && tempRect.top <event.getY() && tempRect.bottom > event.getY())
//			{
//				Log.i("In If: ", "Contains");
//				
//				if (i == 0)
//				{
//					item_clicked = 1;
//					Toast.makeText(getContext(), "Setting  Clicked", 1000).show();
//				}
//				else if(i==1)
//				{
//					item_clicked = 2;
//					Toast.makeText(getContext(), "Scanning  Clicked", 1000).show();
//				}
//				else if(i==2)
//				{
//					item_clicked = 3;
//					Toast.makeText(getContext(), "Manual  Clicked", 1000).show();
//				}
//				else
//				{
//					item_clicked = 4;
//					Toast.makeText(getContext(), "Logout  Clicked", 1000).show();
//				}
//				
//			}
//			}
//		}
//		
//		
//		
//		
//		if(event.getAction() == MotionEvent.ACTION_UP){
//			on_moved = 1;
//		}
//		return true;
//	}
	
	 
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
	    canvasthread.setRunning(true);
	    canvasthread.start();

		
	}
	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		boolean retry = true;
		canvasthread.setRunning(false);
		while (retry) {
			try {
				canvasthread.join();
				retry = false;
			} catch (InterruptedException e) {
				// we will try it again and again...
			}
		}

	}




	@Override
	public boolean onDown(MotionEvent e) {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		// TODO Auto-generated method stub
		return false;
	}




	@Override
	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {	
		return true;
	}


}   