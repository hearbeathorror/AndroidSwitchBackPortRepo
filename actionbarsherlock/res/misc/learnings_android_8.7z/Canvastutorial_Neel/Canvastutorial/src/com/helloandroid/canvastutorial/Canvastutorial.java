package com.helloandroid.canvastutorial;

import static com.nineoldandroids.view.ViewHelper.setTranslationX;
import static com.nineoldandroids.view.ViewHelper.setTranslationY;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("NewApi")
public class Canvastutorial extends Activity implements OnClickListener {
	
	public int width;
	public int height;
	public ImageView img_setting,img_changepin,img_manual,img_scanning; 
	TextView tv_x,tv_y;
	float radius;
	 int current_x ;
	 int current_y;
	 int index_of_1;
	 int index_of_2;
	 int i;
	 int down_y;
	 int down_x;
	 Handler mTimer;
     private Handler mHandler = new Handler();

//	AbsoluteLayout.LayoutParams absParams,absParams2,absParams3,absParams4,absParams0;
	ArrayList<Point> points_X = new ArrayList<Point>();
	ArrayList<Point> original_X = new ArrayList<Point>();
	BitmapDrawable bd;
	RelativeLayout l1;
	ImageView curve_image;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        curve_image = (ImageView)findViewById(R.id.imageView1);        
        l1 = (RelativeLayout) findViewById(R.id.llView);
      
        
        
        
        DisplayMetrics metrics = new DisplayMetrics();
        int densityDpi = (int)(metrics.density * 160f);        
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        switch(metrics.densityDpi){
        
             case DisplayMetrics.DENSITY_LOW:
            	 		//NOT SUPPORTED
                        break;
             case DisplayMetrics.DENSITY_MEDIUM:            	 
            	 		curve_image.setImageResource(R.drawable.curvehdpi); //Tested on 7" tablet
            	 		Toast.makeText(getApplicationContext(), "Tablet" ,Toast.LENGTH_SHORT ).show();
            	 		bd=(BitmapDrawable) this.getResources().getDrawable(R.drawable.curvehdpi);
            	 		height=bd.getBitmap().getHeight();
            	 		width=bd.getBitmap().getWidth();
            	 		radius = (height/2);
                        break;
             case DisplayMetrics.DENSITY_HIGH: //Tested on emmulator            	 
            	 		curve_image.setImageResource(R.drawable.curve_med1);
            	 		Toast.makeText(getApplicationContext(), "Immulator" ,Toast.LENGTH_SHORT ).show();
            	 		bd=(BitmapDrawable) this.getResources().getDrawable(R.drawable.curve_med1);
            	 		height=bd.getBitmap().getHeight();
            	 		width=bd.getBitmap().getWidth();
            	 		radius = (height/2);                 		
                        break;
             case DisplayMetrics.DENSITY_XHIGH:
            	 		Toast.makeText(getApplicationContext(), "Galaxy" ,Toast.LENGTH_SHORT ).show();
            	 		curve_image.setImageResource(R.drawable.curve_med);
            	 		bd=(BitmapDrawable) this.getResources().getDrawable(R.drawable.curve_med);
            	 		height=bd.getBitmap().getHeight();
            	 		width=bd.getBitmap().getWidth();
            	 		radius = (height/2);
                 		break;
        }
        
        
       
       
        
        
        //DebugUIAdapter mUI = new DebugUIAdapter();
        //UpdateTimer mTimer = new UpdateTimer(mUI);
        
        
        Display display = getWindowManager().getDefaultDisplay(); 
        float width1 = display.getWidth();  // deprecated
        float height1 = display.getHeight();  // deprecated
        Panel mPanel = new Panel(getApplicationContext());
        img_setting = new ImageView(getApplicationContext());
        img_setting.setImageResource(R.drawable.red);        
        img_setting.setOnClickListener(this);
        img_setting.setId(R.id.button_1);
//        img_setting.setOnTouchListener(this);
        
        //2nd button
        img_changepin = new ImageView(getApplicationContext());
        img_changepin.setImageResource(R.drawable.red);        
        img_changepin.setOnClickListener(this);
        img_changepin.setId(R.id.button_2);
//        img_changepin.setOnTouchListener(this);
        
        //3rd button
        img_manual = new ImageView(getApplicationContext());
        img_manual.setImageResource(R.drawable.red);        
        img_manual.setOnClickListener(this);
        img_manual.setId(R.id.button_3);
//        img_manual.setOnTouchListener(this);
        
        
        //4th button
        img_scanning = new ImageView(getApplicationContext());
        img_scanning.setImageResource(R.drawable.red);        
        img_scanning.setOnClickListener(this);
        img_scanning.setId(R.id.button_4);
//        img_scanning.setOnTouchListener(this);
        
        
//        AbsoluteLayout fl = new AbsoluteLayout(getApplicationContext());        
       
        //l1.addView(mPanel);
        l1.addView(img_setting);
        l1.addView(img_changepin);
        l1.addView(img_manual);
        l1.addView(img_scanning);        
        
        //setContentView(fl);                
   /*     img_changepin.bringToFront();
        img_manual.bringToFront();
        img_scanning.bringToFront();*/
        
//        absParams = (AbsoluteLayout.LayoutParams)img_setting.getLayoutParams();
//        absParams2 = (AbsoluteLayout.LayoutParams)img_changepin.getLayoutParams();
//        absParams3 = (AbsoluteLayout.LayoutParams)img_manual.getLayoutParams();
//        absParams4 = (AbsoluteLayout.LayoutParams)img_scanning.getLayoutParams();
        
        img_setting.bringToFront();
        img_changepin.bringToFront();
        img_manual.bringToFront();
        img_scanning.bringToFront();
        
//        radius = (height/2) - 50;
         /* for(int a = -360; a < 360; a += 1) {

        	  double device_black = (height1) - (height);
  			
  			
			int x = (int) (radius * Math.cos(a)); 
			int  y = (int) (((height1/2) + device_black) - Math.sin(a) * radius);		
			Point pt = new Point();
			pt.x = x;
			pt.y= y;
			points_X.add(pt);
			
			//canvas.drawPoint(d1, d2, p1);
		}       */
        for(int i = 0 ; i<4 ; i++){
        	
			float mAngle = (float) ((Math.PI / 3 )- i * Math.PI / 4.5);
			
			 Log.e("angle  ", "" + mAngle);
			 Log.e("radius  ", "" + radius);
			
			double x = 0 + Math.cos(mAngle) * radius;
			float  y = (float) (((height/2)) - Math.sin(mAngle) * radius);		
			 Point pt = new Point();
			pt.x = (int) x; 
			pt.y = (int) y;
			original_X.add(pt);
			
			if(i==0){
//				absParams.x = (int) x;
//			absParams.y = (int) y;
//			img_setting.setLayoutParams(absParams);
				setTranslationX(img_setting,(float) x);
				setTranslationY(img_setting,(float) y);
				img_setting.requestLayout();
//				 img_setting.bringToFront();
			//Log.e("canvas", "img_setting init pos : " + absParams.x + " : " + absParams.y);
			}
			else if(i==1){
				setTranslationX(img_changepin,(float) x);
				setTranslationY(img_changepin,(float) y);
				img_changepin.requestLayout();
			}
			else if(i==2){
				setTranslationX(img_manual,(float) x);
				setTranslationY(img_manual,(float) y);
				img_manual.requestLayout();
			}
			else if(i==3){
				setTranslationX(img_scanning,(float) x);
				setTranslationY(img_scanning,(float) y);
				img_scanning.requestLayout();
			}
			
        }
        
        l1.setOnTouchListener(tlobj);
        
    }
    
//    public void resetPosition(){
//    	
//    	 for(int i = 0 ; i<4 ; i++){ 			
// 			if(i==0){
// 				absParams.x = (int) original_X.get(i).x;
// 				absParams.y = (int) original_X.get(i).y;
// 				img_setting.setLayoutParams(absParams);
// 			}else if(i==1){
// 				absParams2.x = (int) original_X.get(i).x;
// 				absParams2.y = (int) original_X.get(i).y;
// 				img_changepin.setLayoutParams(absParams2);}
// 			else if(i==2){
// 				absParams3.x = (int) original_X.get(i).x;
// 				absParams3.y = (int) original_X.get(i).y;
// 				img_manual.setLayoutParams(absParams3);}
// 			else if(i==3){
// 				absParams4.x = (int) original_X.get(i).x;
// 				absParams4.y = (int) original_X.get(i).y;
// 				img_scanning.setLayoutParams(absParams4);}
//         }
//    }
    
    
    
    private OnTouchListener tlobj = new OnTouchListener() {
		
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			// TODO Auto-generated method stub
			
			switch (event.getAction()) {
			case MotionEvent.ACTION_MOVE:
				
				float delta_y = event.getRawY() - down_y;
				
				
				//int ay = (int) delta_y;
				
				int newY = (int) (originalY + delta_y);
				
				//Log.e("canvas", "ontouch move : " + String.valueOf(delta_y) + " : " + String.valueOf(newY));
				
				
				int ax = (int) Math.sqrt((radius * radius) - ((newY - height/2) * (newY - height/2)));
				//Log.e("canvas", "ontouch move 2: " + String.valueOf(ax) + " : " + String.valueOf(newY - height/2));
				Log.e("canvas", "ontouch move 2: " + String.valueOf(ax) + " : " + String.valueOf(newY));
				
//				absParams.x = (int) ax;			
//				absParams.y = newY;//(int) event.getRawY();
//				//LayoutParams l1 = img_setting.getLayoutParams();
	//
//				img_setting.setLayoutParams(absParams);
				
				setTranslationX(img_setting, ax);
				setTranslationY(img_setting, newY);
				
				//v.setLayoutParams(absParams0);
				
				
				break;
			case MotionEvent.ACTION_UP:
				//resetPosition();
				break;
			case MotionEvent.ACTION_DOWN:
				
				originalY = img_setting.getTop(); //(int) original_X.get(0).y;
				originalX = img_setting.getLeft(); //(int) original_X.get(0).y;
				down_y = (int) event.getRawY(); //(int) original_X.get(0).x;  //event.getRawY();
				Log.e("canvas", "ontouch down : " + String.valueOf(originalY) 
						+ " : " + String.valueOf(originalX)
						+ " : " + String.valueOf(down_y)
						+ " : " + String.valueOf(height)
						+ " : " + String.valueOf(radius));
				//down_x = (int) original_X.get(0).y; //event.getRawX();
				break;
			default:
				break;
			}
			return false;
		}
			
	};
   
        
    @Override    
	public void onClick(View v) {		
		switch (v.getId()) {
		case R.id.button_1:
			
			Toast.makeText(getApplicationContext(), "Setting clicked!", Toast.LENGTH_SHORT).show();
			break;

		default:
			break;
		}
	}

	
    
	public boolean onMyTouch(final View v, MotionEvent event) {
		switch (event.getAction()) {
		case MotionEvent.ACTION_MOVE:
			
			float delta_y = event.getRawY() - down_y;
			
			
			//int ay = (int) delta_y;
			
			int newY = (int) (originalY + delta_y);
			
			//Log.e("canvas", "ontouch move : " + String.valueOf(delta_y) + " : " + String.valueOf(newY));
			
			
			int ax = (int) Math.sqrt((radius * radius) - ((newY - height/2) * (newY - height/2)));
			//Log.e("canvas", "ontouch move 2: " + String.valueOf(ax) + " : " + String.valueOf(newY - height/2));
			Log.e("canvas", "ontouch move 2: " + String.valueOf(ax) + " : " + String.valueOf(newY));
			
//			absParams.x = (int) ax;			
//			absParams.y = newY;//(int) event.getRawY();
//			//LayoutParams l1 = img_setting.getLayoutParams();
//
//			img_setting.setLayoutParams(absParams);
			
			setTranslationX(img_setting, ax);
			setTranslationY(img_setting, newY);
			
			//v.setLayoutParams(absParams0);
			
			
			break;
		case MotionEvent.ACTION_UP:
			//resetPosition();
			break;
		case MotionEvent.ACTION_DOWN:
			
			originalY = img_setting.getTop(); //(int) original_X.get(0).y;
			originalX = img_setting.getLeft(); //(int) original_X.get(0).y;
			down_y = (int) event.getRawY(); //(int) original_X.get(0).x;  //event.getRawY();
			Log.e("canvas", "ontouch down : " + String.valueOf(originalY) 
					+ " : " + String.valueOf(originalX)
					+ " : " + String.valueOf(down_y)
					+ " : " + String.valueOf(height)
					+ " : " + String.valueOf(radius));
			//down_x = (int) original_X.get(0).y; //event.getRawX();
			break;
		default:
			break;
		}
		
		return true;
	}
	
	int originalX;
	int originalY;
}