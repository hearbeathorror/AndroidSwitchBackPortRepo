/** Automatically generated file. DO NOT MODIFY */
package com.helloandroid.canvastutorial;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}